pca_fit <- prcomp(Xc, center = FALSE, scale. = FALSE)

#2차원
Z_PCA2 <- pca_fit$x[, 1:2]
colnames(Z_PCA2) <- paste0("PC", 1:2)
loan_pca2 <- data.frame(Z_PCA2, loan_status = Y)
#write.csv(loan_pca2, "loan_pca_2d.csv", row.names = FALSE)

#loan_pca2 <- read.csv("loan_pca_2d.csv")

# 로지스틱 회귀 적합
fit_pca2 <- glm(loan_status ~ ., data = loan_pca2, family = binomial(link = "logit"))

# 예측
pred_prob2 <- predict(fit_pca2, type = "response")
pred_class2 <- ifelse(pred_prob2 > 0.5, 1, 0)

# 성능 평가
conf_mat2 <- confusionMatrix(as.factor(pred_class2), as.factor(loan_pca2$loan_status))
roc_obj2 <- roc(loan_pca2$loan_status, pred_prob2)

cat("=== PCA 2차원 ===\n")
cat("Accuracy :", conf_mat2$overall["Accuracy"], "\n")
cat("Precision:", conf_mat2$byClass["Precision"], "\n")
cat("Recall   :", conf_mat2$byClass["Recall"], "\n")
cat("F1-score :", conf_mat2$byClass["F1"], "\n")
cat("AUC      :", auc(roc_obj2), "\n\n")

#4차원
Z_PCA4 <- pca_fit$x[, 1:4]
colnames(Z_PCA4) <- paste0("PC", 1:4)
loan_pca4 <- data.frame(Z_PCA4, loan_status = Y)
#write.csv(loan_pca4, "loan_pca_4d.csv", row.names = FALSE)

#loan_pca4 <- read.csv("loan_pca_4d.csv")

fit_pca4 <- glm(loan_status ~ ., data = loan_pca4, family = binomial(link = "logit"))

pred_prob4 <- predict(fit_pca4, type = "response")
pred_class4 <- ifelse(pred_prob4 > 0.5, 1, 0)

conf_mat4 <- confusionMatrix(as.factor(pred_class4), as.factor(loan_pca4$loan_status))
roc_obj4 <- roc(loan_pca4$loan_status, pred_prob4)

cat("=== PCA 4차원 ===\n")
cat("Accuracy :", conf_mat4$overall["Accuracy"], "\n")
cat("Precision:", conf_mat4$byClass["Precision"], "\n")
cat("Recall   :", conf_mat4$byClass["Recall"], "\n")
cat("F1-score :", conf_mat4$byClass["F1"], "\n")
cat("AUC      :", auc(roc_obj4), "\n")



conf_mat2

conf_mat4


