install.packages("fastDummies")
library(fastDummies)
install.packages("pROC")
library(pROC)


loan <- read.csv("C:/Users/bluem/Desktop/고차원자료분석/loan_small.csv")

Y <- loan$loan_status
X <- subset(loan, select = -loan_status)

X_dummy <- fastDummies::dummy_cols(X, 
                                   remove_first_dummy = TRUE, 
                                   remove_selected_columns = TRUE)

Xc <- scale(as.matrix(X_dummy), center = TRUE, scale = TRUE)


find_best_k_pca <- function(Xmat, Yvec, K_max = 10) {
  
  pca_fit <- prcomp(Xmat, center = FALSE, scale. = FALSE)
  auc_list <- numeric(K_max)
  
  for (k in 1:K_max) {
    Z <- pca_fit$x[, 1:k]
    df <- data.frame(Y = Yvec, Z)
    
    fit <- glm(Y ~ ., data = df, family = binomial())
    probs <- predict(fit, type = "response")
    
    auc_list[k] <- pROC::auc(pROC::roc(Yvec, probs))
    
    cat("k =", k, "AUC =", auc_list[k], "\n")
  }
  
  # AUC Plot
  plot(1:K_max, auc_list, type = "b", pch = 19,
       main = "PCA Dimension vs AUC",
       xlab = "k (PCs)", ylab = "AUC")
  
  best_k <- which.max(auc_list)
  cat("Best PCA k =", best_k,
      "with AUC =", round(auc_list[best_k], 4), "\n")
  
  return(best_k)
}

#bestK
set.seed(123)
best_k_pca <- find_best_k_pca(Xc, Y, K_max = 10)




#----------------------------------------------------------------------------------#

pca_fit <- prcomp(Xc, center = FALSE, scale. = FALSE)

#2차원
Z_PCA2 <- pca_fit$x[, 1:2]
colnames(Z_PCA2) <- paste0("PC", 1:2)
loan_pca2 <- data.frame(Z_PCA2, loan_status = Y)
write.csv(loan_pca2, "loan_pca_2d.csv", row.names = FALSE)

#4차원
Z_PCA4 <- pca_fit$x[, 1:4]
colnames(Z_PCA4) <- paste0("PC", 1:4)
loan_pca4 <- data.frame(Z_PCA4, loan_status = Y)
write.csv(loan_pca4, "loan_pca_4d.csv", row.names = FALSE)

#----------------------------------------------------------------------------------#











pca_fit <- prcomp(Xc, center = FALSE, scale. = FALSE)
Z_PCA <- pca_fit$x[, 1:best_k_pca]
colnames(Z_PCA) <- paste0("PC", 1:best_k_pca)

loan_pca <- data.frame(Z_PCA, loan_status = Y)
write.csv(loan_pca, "loan_pca.csv", row.names = FALSE)






library(energy)
library(fastDummies)
library(pROC)

# -------------------------------
# 1. 데이터 불러오기 및 샘플링
# -------------------------------
data_small <- read.csv('C:/Users/bluem/Desktop/고차원자료분석/loan_small.csv')


# -------------------------------
# 2. X, Y 분리 및 더미화 + 표준화
# -------------------------------
Y <- as.numeric(data_small$loan_status)
X <- subset(data_small, select = -loan_status)

X_dummy <- dummy_cols(X, remove_first_dummy = TRUE, remove_selected_columns = TRUE)
Xc <- scale(as.matrix(X_dummy))

# -------------------------------
# 3. 거리공분산 기반 단일 방향 추정 함수
# -------------------------------
find_sdr_direction <- function(Xmat, Yvec) {
  obj_fn <- function(t_vec) {
    b <- t_vec / sqrt(sum(t_vec^2) + 1e-12)
    proj <- as.vector(Xmat %*% b)
    - (dcov(proj, Yvec))^2                # negative ⇒ maximize dcov
  }
  p <- ncol(Xmat)
  fit <- optim(par = rnorm(p), fn = obj_fn, method = "BFGS",
               control = list(maxit = 800))
  b_hat <- fit$par / sqrt(sum(fit$par^2) + 1e-12)
  return(b_hat)
}

# -------------------------------
# 4. Deflation 기반 다중 방향 추정 함수
# -------------------------------
find_multiple_directions <- function(Xmat, Yvec, k = 2) {
  Xres <- Xmat
  p <- ncol(Xmat)
  Bs <- matrix(0, p, k)
  
  for (j in 1:k) {
    b_hat <- find_sdr_direction(Xres, Yvec)
    Bs[, j] <- b_hat
    Xres <- Xres - (Xres %*% b_hat) %*% t(b_hat)   # deflation
  }
  return(Bs)
}

# -------------------------------
# 5. k = 4 로 고정하여 SDR 수행
# -------------------------------
k_opt <- 4

cat("Estimating SDR with k =", k_opt, "...\n")
B_final <- find_multiple_directions(Xc, Y, k = k_opt)

Z_final <- Xc %*% B_final
colnames(Z_final) <- paste0("Z", 1:k_opt)

# -------------------------------
# 6. 결과 저장
# -------------------------------
write.csv(Z_final, "loan_sdr.csv", row.names = FALSE)




df_sdr <- data.frame(Y = Y, Z_final)
head(df_sdr)



fit <- glm(Y ~ ., data = df_sdr, family = binomial(link = "logit"))
summary(fit)



pred_prob <- predict(fit, type = "response")



pred_class <- ifelse(pred_prob > 0.5, 1, 0)






library(caret)
conf_mat <- confusionMatrix(as.factor(pred_class), as.factor(df_sdr$Y))
print(conf_mat)

# -------------------------------
# 5. 주요 성능 지표
# -------------------------------
accuracy  <- conf_mat$overall["Accuracy"]
precision <- conf_mat$byClass["Precision"]
recall    <- conf_mat$byClass["Recall"]
f1_score  <- conf_mat$byClass["F1"]

cat("Accuracy :", accuracy, "\n")
cat("Precision:", precision, "\n")
cat("Recall   :", recall, "\n")
cat("F1-score :", f1_score, "\n")

# -------------------------------
# 6. ROC & AUC
# -------------------------------
library(pROC)
roc_obj <- roc(df_sdr$Y, pred_prob)
auc_value <- auc(roc_obj)
cat("AUC      :", auc_value, "\n")

# -------------------------------
# 7. ROC Curve 시각화 (선택)
# -------------------------------
plot(roc_obj, col = "blue", lwd = 2, main = "ROC Curve")








