install.packages("fastDummies")
library(fastDummies)
install.packages("pROC")
library(pROC)


loan <- read.csv("C:/Users/bluem/Desktop/고차원자료분석/data_small.csv")
# 파일 경로 속성으로 DS/~ 나오면 슬래시 방향만 /로 바꿔주세요.

Y <- loan$loan_status
X <- subset(loan, select = -loan_status)

X_dummy <- fastDummies::dummy_cols(X, 
                                   remove_first_dummy = TRUE, 
                                   remove_selected_columns = TRUE)

Xc <- scale(as.matrix(X_dummy), center = TRUE, scale = TRUE)


find_best_k_pca <- function(Xmat, Yvec, K_max = 10) {
  
  pca_fit <- prcomp(Xmat, center = FALSE, scale. = FALSE)
  auc_list <- numeric(K_max)
  
  for (k in 1:K_max) {
    Z <- pca_fit$x[, 1:k]
    df <- data.frame(Y = Yvec, Z)
    
    fit <- glm(Y ~ ., data = df, family = binomial())
    probs <- predict(fit, type = "response")
    
    auc_list[k] <- pROC::auc(pROC::roc(Yvec, probs))
    
    cat("k =", k, "AUC =", auc_list[k], "\n")
  }
  
  # AUC Plot
  plot(1:K_max, auc_list, type = "b", pch = 19,
       main = "PCA Dimension vs AUC",
       xlab = "k (PCs)", ylab = "AUC")
  
  best_k <- which.max(auc_list)
  cat("Best PCA k =", best_k,
      "with AUC =", round(auc_list[best_k], 4), "\n")
  
  return(best_k)
}


# bestK
set.seed(123)
best_k_pca <- find_best_k_pca(Xc, Y, K_max = 10)








pca_fit <- prcomp(Xc, center = FALSE, scale. = FALSE)
Z_PCA <- pca_fit$x[, 1:best_k_pca]
colnames(Z_PCA) <- paste0("PC", 1:best_k_pca)

loan_pca <- data.frame(Z_PCA, loan_status = Y)
write.csv(loan_pca, "loan_pca.csv", row.names = FALSE)









pca_fit <- prcomp(Xc, center = FALSE, scale. = FALSE)

# 2차원
Z_PCA2 <- pca_fit$x[, 1:2]
colnames(Z_PCA2) <- paste0("PC", 1:2)
loan_pca2 <- data.frame(Z_PCA2, loan_status = Y)
write.csv(loan_pca2, "loan_pca_2d.csv", row.names = FALSE)

# 4차원
Z_PCA4 <- pca_fit$x[, 1:4]
colnames(Z_PCA4) <- paste0("PC", 1:4)
loan_pca4 <- data.frame(Z_PCA4, loan_status = Y)
write.csv(loan_pca4, "loan_pca_4d.csv", row.names = FALSE)


#2차원

#loan_pca2 <- read.csv("loan_pca_2d.csv")

# 로지스틱 회귀 적합
fit_pca2 <- glm(loan_status ~ ., data = loan_pca2, family = binomial(link = "logit"))

# 예측
pred_prob2 <- predict(fit_pca2, type = "response")
pred_class2 <- ifelse(pred_prob2 > 0.5, 1, 0)

# 성능 평가
conf_mat2 <- confusionMatrix(as.factor(pred_class2), as.factor(loan_pca2$loan_status))
roc_obj2 <- roc(loan_pca2$loan_status, pred_prob2)

cat("=== PCA 2차원 ===\n")
cat("Accuracy :", conf_mat2$overall["Accuracy"], "\n")
cat("Precision:", conf_mat2$byClass["Precision"], "\n")
cat("Recall   :", conf_mat2$byClass["Recall"], "\n")
cat("F1-score :", conf_mat2$byClass["F1"], "\n")
cat("AUC      :", auc(roc_obj2), "\n\n")

# -------------------------------
# 2. PCA 4차원 CSV 불러오기
# -------------------------------
#loan_pca4 <- read.csv("loan_pca_4d.csv")

fit_pca4 <- glm(loan_status ~ ., data = loan_pca4, family = binomial(link = "logit"))

pred_prob4 <- predict(fit_pca4, type = "response")
pred_class4 <- ifelse(pred_prob4 > 0.5, 1, 0)

conf_mat4 <- confusionMatrix(as.factor(pred_class4), as.factor(loan_pca4$loan_status))
roc_obj4 <- roc(loan_pca4$loan_status, pred_prob4)

cat("=== PCA 4차원 ===\n")
cat("Accuracy :", conf_mat4$overall["Accuracy"], "\n")
cat("Precision:", conf_mat4$byClass["Precision"], "\n")
cat("Recall   :", conf_mat4$byClass["Recall"], "\n")
cat("F1-score :", conf_mat4$byClass["F1"], "\n")
cat("AUC      :", auc(roc_obj4), "\n")

print(conf_mat)
print(conf_mat2)
