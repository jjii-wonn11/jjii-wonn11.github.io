# -------------------------
# 0. 패키지 설치/로드
install.packages(c("energy","expm","Matrix","caret","pROC"))
library(energy)
library(expm)
library(Matrix)
library(caret)
library(pROC)

# -------------------------
# 1. 데이터 전처리 함수
preprocess_data <- function(X_raw, Y_raw, scale_X = TRUE){
  if(is.data.frame(X_raw)){
    dv <- dummyVars(~ ., data = X_raw, fullRank = TRUE)
    X_mat <- predict(dv, X_raw)
  } else {
    X_mat <- as.matrix(X_raw)
  }
  if(scale_X){
    X_mat <- scale(X_mat)
  }
  if(is.factor(Y_raw)) {
    y <- as.numeric(as.integer(Y_raw) - 1)
  } else {
    y <- as.numeric(Y_raw)
  }
  list(X = as.matrix(X_mat), Y = y)
}

# -------------------------
# 2. SDR 목적함수 만들기
make_obj_fun <- function(X, Y, d){
  p <- ncol(X)
  Sigma_hat <- cov(X)
  Sigma_hat_reg <- Sigma_hat + 1e-6 * diag(p)
  Sigma_inv_sqrt <- solve(sqrtm(Sigma_hat_reg))
  X_whiten_t <- Sigma_inv_sqrt %*% t(X)
  
  fn <- function(U_vec){
    U <- matrix(U_vec, nrow = p, ncol = d)
    # QR 직교화로 근사
    qrU <- qr(U)
    U <- qr.Q(qrU)[,1:d]
    Z_dn <- t( t(U) %*% X_whiten_t )
    dcov_val <- dcov(Z_dn, Y)
    return( - as.numeric(dcov_val) )
  }
  list(fn = fn, p = p)
}

# -------------------------
# 3. 거리공분산 SDR 최적화 (Windows용)
run_dcov_sdr <- function(X, Y, d = 2, maxiter = 500, verbose = FALSE){
  pre <- make_obj_fun(X, Y, d)
  fn <- pre$fn
  p <- pre$p
  
  # 초기값
  U0 <- matrix(rnorm(p*d), nrow = p, ncol = d)
  U0_vec <- as.numeric(U0)
  
  # optim으로 L-BFGS-B 근사
  res <- optim(U0_vec, fn, method="L-BFGS-B", control=list(maxit=maxiter))
  
  U_opt <- matrix(res$par, nrow = p, ncol = d)
  # QR 직교화
  qrU <- qr(U_opt)
  U_opt <- qr.Q(qrU)[,1:d]
  
  Sigma_hat <- cov(X)
  Sigma_hat_reg <- Sigma_hat + 1e-6 * diag(p)
  Sigma_inv_sqrt <- solve(sqrtm(Sigma_hat_reg))
  beta_hat <- Sigma_inv_sqrt %*% U_opt
  Z <- as.matrix(X) %*% beta_hat
  
  if(verbose){
    cat("Optim convergence:", res$convergence, "\n")
    cat("Final objective (neg dCov):", res$value, "\n")
    cat("Returned beta shape:", dim(beta_hat), "\n")
  }
  
  list(beta = beta_hat, Z = Z)
}

# -------------------------
# 4. 로지스틱 회귀 적합 함수
fit_logistic_on_reduced <- function(Z, Y){
  df <- data.frame(Y = Y, Z)
  znames <- paste0("V", 1:ncol(Z))
  colnames(df) <- c("Y", znames)
  fmla <- as.formula(paste("Y ~", paste(znames, collapse = " + ")))
  fit <- glm(fmla, family = binomial(), data = df)
  fit
}

# -------------------------
# 5. 전체 파이프라인 + 최적 d 선택 + confusion matrix
X_raw <- data_small[, setdiff(names(data_small), "loan_status")]
Y_raw <- data_small$loan_status
pre <- preprocess_data(X_raw, Y_raw)

d_list <- 1:5
auc_list <- numeric(length(d_list))
Z_list <- list()
fit_list <- list()

for(i in seq_along(d_list)){
  d <- d_list[i]
  cat("Running SDR for d =", d, "...\n")
  out <- run_dcov_sdr(pre$X, pre$Y, d = d, verbose = FALSE)
  Z <- out$Z
  fit <- fit_logistic_on_reduced(Z, pre$Y)
  
  pred_probs <- predict(fit, type = "response")
  roc_obj <- roc(pre$Y, pred_probs)
  auc_list[i] <- as.numeric(auc(roc_obj))
  
  Z_list[[i]] <- Z
  fit_list[[i]] <- fit
}

best_index <- which.max(auc_list)
best_d <- d_list[best_index]
cat("Best d =", best_d, "with AUC =", auc_list[best_index], "\n")

Z_best <- Z_list[[best_index]]
fit_best <- fit_list[[best_index]]

# 최종 confusion matrix
pred_probs <- predict(fit_best, type = "response")
pred_class <- ifelse(pred_probs > 0.5, 1, 0)
conf_mat <- table(Predicted = pred_class, Actual = pre$Y)
cat("Confusion Matrix:\n")
print(conf_mat)

# 축소 데이터 저장
write.csv(Z_best, "Z_reduced_best.csv", row.names = FALSE)











preprocess_data <- function(X_raw, Y_raw, scale_X = TRUE){
  if(is.data.frame(X_raw)){
    # 더미 변수 변환 (dummyVars, fullRank)
    dv <- dummyVars(~ ., data = X_raw, fullRank = TRUE)
    X_mat <- predict(dv, X_raw)
  } else {
    X_mat <- as.matrix(X_raw)
  }
  if(scale_X){
    X_mat <- scale(X_mat)
  }
  if(is.factor(Y_raw)) {
    y <- as.numeric(as.integer(Y_raw) - 1)
  } else {
    y <- as.numeric(Y_raw)
  }
  list(X = as.matrix(X_mat), Y = y)
}

X_raw <- data_small[, setdiff(names(data_small), "loan_status")]
Y_raw <- data_small$loan_status
pre <- preprocess_data(X_raw, Y_raw)


search()
exists("dummyVars", where = "package:caret")
