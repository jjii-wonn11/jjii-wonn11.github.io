library(energy)
library(fastDummies)
library(pROC)


data_small <- read.csv('C:/Users/bluem/Desktop/고차원자료분석/data_small.csv')


Y <- as.numeric(data_small$loan_status)
X <- subset(data_small, select = -loan_status)

X_dummy <- dummy_cols(X, remove_first_dummy = TRUE, remove_selected_columns = TRUE)
Xc <- scale(as.matrix(X_dummy))

find_sdr_direction <- function(Xmat, Yvec) {
  obj_fn <- function(t_vec) {
    b <- t_vec / sqrt(sum(t_vec^2) + 1e-12)
    proj <- as.vector(Xmat %*% b)
    - (dcov(proj, Yvec))^2                # negative ⇒ maximize dcov
  }
  p <- ncol(Xmat)
  fit <- optim(par = rnorm(p), fn = obj_fn, method = "BFGS",
               control = list(maxit = 800))
  b_hat <- fit$par / sqrt(sum(fit$par^2) + 1e-12)
  return(b_hat)
}


find_multiple_directions <- function(Xmat, Yvec, k = 2) {
  Xres <- Xmat
  p <- ncol(Xmat)
  Bs <- matrix(0, p, k)
  
  for (j in 1:k) {
    b_hat <- find_sdr_direction(Xres, Yvec)
    Bs[, j] <- b_hat
    Xres <- Xres - (Xres %*% b_hat) %*% t(b_hat)   # deflation
  }
  return(Bs)
}


k_opt <- 4

cat("Estimating SDR with k =", k_opt, "...\n")
B_final <- find_multiple_directions(Xc, Y, k = k_opt)

Z_final <- Xc %*% B_final
colnames(Z_final) <- paste0("Z", 1:k_opt)

write.csv(Z_final, "loan_sdr.csv", row.names = FALSE)