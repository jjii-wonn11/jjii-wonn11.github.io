install.packages("readxl")
install.packages("dplyr")
install.packages("tidyr")
install.packages("lubridate")
install.packages("zoo")
install.packages("tibble")
install.packages("readr")
install.packages("stringr")

library(readxl)
library(dplyr)
library(tidyr)
library(lubridate)
library(zoo)
library(tibble)
library(readr)
library(stringr)

esi_raw  <- read_excel("C:/Users/bluem/Desktop/빅데캠/경제심리지수_21225739.xlsx", sheet = "데이터")

names(esi_raw)


##################경제심리지수 월별 데이터 생성##################
month_cols <- grep("^\\d{4}/\\d{2}$", names(esi_raw), value = TRUE)

esi_monthly <- esi_raw %>%
  filter(계정항목 == "경제심리지수(원계열)") %>%
  select(all_of(month_cols)) %>%
  pivot_longer(
    cols = everything(),
    names_to = "month_chr",
    values_to = "esi"
  ) %>%
  mutate(
    month = as.Date(paste0(month_chr, "/01"), format = "%Y/%m/%d"),
    esi = as.numeric(esi),
    log_esi = log(esi)
  ) %>%
  filter(!is.na(month), !is.na(log_esi)) %>%
  select(month, esi, log_esi) %>%
  arrange(month)

esi_monthly

nrow(esi_monthly)

##################일별 데이터로 확장##################
esi_daily <- esi_monthly %>%
  rowwise() %>%
  mutate(
    date = list(seq.Date(
      from = month,
      to = ceiling_date(month, "month") - days(1),
      by = "day",
      format="%Y%m%d"
    ))
  ) %>%
  unnest(date) %>%
  ungroup() %>%
  arrange(date) %>%
  mutate(
    log_esi_ma30 = rollapplyr(
      lag(log_esi, 1),
      width = 30,
      FUN = mean,
      fill = NA,
      partial = FALSE
    )
  ) %>%
  select(date, log_esi_ma30)

esi_daily








cpi_raw  <- read_excel("C:/Users/bluem/Desktop/빅데캠/소비자물가지수(지출목적별)_20260421225613.xlsx", sheet = "데이터")

##################소비자물가지수 월별 데이터 생성##################
cpi_monthly <- cpi_raw %>%
  slice(-(1:2)) %>%
  select(1, 2)

names(cpi_monthly) <- c("month_chr", "cpi")

cpi_monthly


##################물가상승률 계산##################
cpi_monthly <- cpi_monthly %>%
  mutate(
    month_chr = as.character(month_chr),
    cpi = as.numeric(cpi),
    month_chr2 = gsub("\\.\\s*", "-", month_chr),
    month = as.Date(paste0(month_chr2, "-01"), format = "%Y-%m-%d")
  ) %>%
  filter(!is.na(month), !is.na(cpi)) %>%
  arrange(month) %>%
  mutate(
    cpi_inflation_mom = 100 * (log(cpi) - lag(log(cpi)))
  ) %>%
  select(month, cpi, cpi_inflation_mom)

cpi_monthly


##################월별->일별(직전 30일 이동평균)##################
cpi_daily <- cpi_monthly %>%
  rowwise() %>%
  mutate(
    date = list(seq.Date(
      from = month,
      to = ceiling_date(month, "month") - days(1),
      by = "day"
    ))
  ) %>%
  unnest(date) %>%
  ungroup() %>%
  arrange(date) %>%
  mutate(
    cpi_inflation_ma30 = rollapplyr(
      lag(cpi_inflation_mom, 1),
      width = 30,
      FUN = mean,
      fill = NA,
      partial = FALSE
    )
  ) %>%
  select(date, cpi_inflation_ma30)

cpi_daily


##################경제심리지수+물가상승률##################
macro_daily <- esi_daily %>%
  left_join(cpi_daily, by = "date")

macro_daily


##################매크로 제대로 생성됐는지 확인##################

head(macro_daily, 40)
tail(macro_daily, 40)

summary(macro_daily)

range(macro_daily$date)

colSums(is.na(macro_daily))




 ##################업종 남기기##################
industry_path <- "C:/Users/bluem/Desktop/빅데캠/업종.xlsx"

industry_raw <- read_excel(
  industry_path,
  sheet = 1,
  col_names = FALSE
)

industry_o <- industry_raw %>%
  slice(-1) %>%
  transmute(
    industry = trimws(gsub("\\s+", " ", as.character(...1))),
    final_flag = toupper(trimws(gsub("\\s+", " ", as.character(...5))))
  ) %>%
  filter(
    !is.na(industry),
    final_flag == "O"
  ) %>%
  distinct(industry)

industry_o
nrow(industry_o)



clean_text <- function(x) {
  trimws(gsub("\\s+", " ", as.character(x)))
}

card_path  <- "C:/Users/bluem/Desktop/빅데캠/1.서울시민의 일별 소비지역별(행정동).csv"

card_raw <- read_csv(
  card_path,
  locale = locale(encoding = "CP949"),
  show_col_types = FALSE,
  col_types = cols(
    기준일자 = col_character(),
    고객행정동코드 = col_character(),
    .default = col_guess()
  )
)

names(card_raw)
head(card_raw)

card_filtered <- card_raw %>%
  mutate(
    업종대분류 = clean_text(업종대분류)
  ) %>%
  semi_join(
    industry_o,
    by = c("업종대분류" = "industry")
  )


card_raw %>%
  mutate(업종대분류 = trimws(gsub("\\s+", " ", as.character(업종대분류)))) %>%
  anti_join(
    industry_o,
    by = c("업종대분류" = "industry")
  ) %>%
  count(업종대분류, sort = TRUE)


##################카드지출 데이터 날짜 형식 맞추기기##################
card_daily <- card_filtered %>%
  mutate(
    date = as.Date(as.character(기준일자), format = "%Y%m%d"),
    region = 가맹점주소시군구,
    sido = 가맹점주소광역시도,
    dong_code = as.character(고객행정동코드),
    industry = 업종대분류,
    card_spending = as.numeric(카드이용금액계),
    card_count = as.numeric(카드이용건수계)
  )

card_daily <- card_daily %>%
  mutate(
    log_card_spending = log(card_spending)
  )

card_daily

card_daily <- card_daily %>%
  filter(card_spending > 0) %>%
  mutate(
    log_card_spending = log(card_spending)
  )

card_daily

##################macro_daily & card_daily 붙이기기##################
macro_daily <- macro_daily %>%
  mutate(date = as.Date(date))

analysis_data <- card_daily %>%
  left_join(macro_daily, by = "date")

analysis_data %>%
  summarise(
    n_row = n(),
    n_date = n_distinct(date),
    min_date = min(date, na.rm = TRUE),
    max_date = max(date, na.rm = TRUE),
    non_missing_esi = sum(!is.na(log_esi_ma30)),
    non_missing_cpi = sum(!is.na(cpi_inflation_ma30)),
    missing_esi = sum(is.na(log_esi_ma30)),
    missing_cpi = sum(is.na(cpi_inflation_ma30))
  )


##################결측치 제거##################
analysis_data2 <- analysis_data %>%
  filter(
    !is.na(log_card_spending),
    !is.na(log_esi_ma30),
    !is.na(cpi_inflation_ma30)
  )

nrow(analysis_data2)

if (nrow(analysis_data2) > 0) {
  print(range(analysis_data2$date))
} else {
  cat("결측 제거 후 남은 행이 없습니다. 날짜 범위나 이동평균 NA 여부를 확인해야 합니다.\n")
}

range(analysis_data2$date)
nrow(analysis_data)
nrow(analysis_data2)

analysis_data2 <- analysis_data2 %>%
  mutate(
    weekday = weekdays(date),
    weekend = ifelse(weekday %in% c("토요일", "일요일"), 1, 0),
    fri_sat = ifelse(weekday %in% c("금요일", "토요일"), 1, 0)
  )


analysis_data2 %>%
  summarise(
    n_row = n(),
    n_date = n_distinct(date),
    n_region = n_distinct(region),
    min_date = min(date),
    max_date = max(date)
  )


model1 <- lm(
  log_card_spending ~ log_esi_ma30 + cpi_inflation_ma30 +
    factor(region) + factor(weekday),
  data = analysis_data2
)

summary(model1)









