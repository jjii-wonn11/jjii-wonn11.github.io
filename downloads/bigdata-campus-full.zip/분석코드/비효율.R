library(readr)
library(dplyr)
library(lubridate)
library(stringr)
library(tibble)
library(writexl)

############################
# 1. B076 유동인구 불러오기
############################

flow_path <- "C:/Users/bluem/Desktop/빅데캠/20191001_OUTPUT.csv"

flow_raw <- read_csv(
  flow_path,
  locale = locale(encoding = "UTF-8"),
  show_col_types = FALSE
)

names(flow_raw)
head(flow_raw)


##################서울 자치구 코드표##################

gu_code <- tibble::tribble(
  ~gu_code4, ~gu,
  "1101", "종로구",
  "1102", "중구",
  "1103", "용산구",
  "1104", "성동구",
  "1105", "광진구",
  "1106", "동대문구",
  "1107", "중랑구",
  "1108", "성북구",
  "1109", "강북구",
  "1110", "도봉구",
  "1111", "노원구",
  "1112", "은평구",
  "1113", "서대문구",
  "1114", "마포구",
  "1115", "양천구",
  "1116", "강서구",
  "1117", "구로구",
  "1118", "금천구",
  "1119", "영등포구",
  "1120", "동작구",
  "1121", "관악구",
  "1122", "서초구",
  "1123", "강남구",
  "1124", "송파구",
  "1125", "강동구"
)

############################
# 3. 유동인구: 행정구 x 일별 합산
############################

flow_gu_day <- flow_raw %>%
  mutate(
    date = as.Date(arv_dt),
    arv_emd_chr = as.character(arv_emd),
    gu_code4 = str_sub(arv_emd_chr, 1, 4),
    FlowIn = as.numeric(popl_cnt)
  ) %>%
  left_join(gu_code, by = "gu_code4") %>%
  filter(
    !is.na(date),
    !is.na(gu),
    !is.na(FlowIn)
  ) %>%
  group_by(gu, date) %>%
  summarise(
    FlowIn = sum(FlowIn, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(gu, date)

flow_gu_day


############################
# 4. 유동인구 확인
############################

flow_gu_day %>%
  summarise(
    n_row = n(),
    n_gu = n_distinct(gu),
    n_date = n_distinct(date),
    min_date = min(date, na.rm = TRUE),
    max_date = max(date, na.rm = TRUE),
    missing_flow = sum(is.na(FlowIn))
  )

flow_gu_day %>%
  count(gu, sort = TRUE)




############################
# 1. 카드소비 remove 데이터 불러오기
############################

card_path <- "C:/Users/bluem/Desktop/빅데캠/remove.csv"

card_remove <- read_csv(
  card_path,
  locale = locale(encoding = "CP949"),
  show_col_types = FALSE
)

names(card_remove)
head(card_remove)

names(card_remove) <- c(
  "gu_9", "sales_9",
  "gu_10", "sales_10",
  "gu_11", "sales_11",
  "gu_12", "sales_12"
)

names(card_remove)

############################
# 2. 카드소비 wide → long 변환
############################

card_9 <- card_remove %>%
  select(
    gu = gu_9,
    Sales = sales_9
  ) %>%
  filter(!is.na(gu), !is.na(Sales)) %>%
  mutate(month_num = 9)

card_10 <- card_remove %>%
  select(
    gu = gu_10,
    Sales = sales_10
  ) %>%
  filter(!is.na(gu), !is.na(Sales)) %>%
  mutate(month_num = 10)

card_11 <- card_remove %>%
  select(
    gu = gu_11,
    Sales = sales_11
  ) %>%
  filter(!is.na(gu), !is.na(Sales)) %>%
  mutate(month_num = 11)

card_12 <- card_remove %>%
  select(
    gu = gu_12,
    Sales = sales_12
  ) %>%
  filter(!is.na(gu), !is.na(Sales)) %>%
  mutate(month_num = 12)

sales_gu_day <- bind_rows(
  card_9,
  card_10,
  card_11,
  card_12
) %>%
  group_by(gu, month_num) %>%
  mutate(
    day = row_number(),
    date = as.Date(
      paste0("2019-", sprintf("%02d", month_num), "-", sprintf("%02d", day))
    )
  ) %>%
  ungroup() %>%
  filter(!is.na(date)) %>%
  mutate(
    Sales = as.numeric(Sales)
  ) %>%
  select(
    gu,
    date,
    Sales
  ) %>%
  arrange(gu, date)

sales_gu_day



############################
# 3. 카드소비 확인
############################

sales_gu_day %>%
  summarise(
    n_row = n(),
    n_gu = n_distinct(gu),
    n_date = n_distinct(date),
    min_date = min(date, na.rm = TRUE),
    max_date = max(date, na.rm = TRUE),
    min_sales = min(Sales, na.rm = TRUE),
    max_sales = max(Sales, na.rm = TRUE),
    missing_sales = sum(is.na(Sales))
  )

sales_gu_day %>%
  count(gu)

sales_gu_day %>%
  arrange(gu, date) %>%
  head(40)


############################
# 4. 카드소비 + 유동인구 병합
############################

mismatch_base <- sales_gu_day %>%
  inner_join(
    flow_gu_day,
    by = c("gu", "date")
  ) %>%
  mutate(
    E_gt = log((Sales + 1) / (FlowIn + 1))
  ) %>%
  arrange(gu, date)

mismatch_base


############################
# 5. 병합 결과 확인
############################

mismatch_base %>%
  summarise(
    n_row = n(),
    n_gu = n_distinct(gu),
    n_date = n_distinct(date),
    min_date = min(date, na.rm = TRUE),
    max_date = max(date, na.rm = TRUE),
    missing_E = sum(is.na(E_gt))
  )

anti_join(
  sales_gu_day,
  flow_gu_day,
  by = c("gu", "date")
) %>%
  summarise(
    card_not_matched = n(),
    min_date = min(date, na.rm = TRUE),
    max_date = max(date, na.rm = TRUE)
  )

anti_join(
  flow_gu_day,
  sales_gu_day,
  by = c("gu", "date")
) %>%
  summarise(
    flow_not_matched = n(),
    min_date = min(date, na.rm = TRUE),
    max_date = max(date, na.rm = TRUE)
  )


############################
# 6. 행정구별 평균 소비효율 계산
############################

mismatch_table <- mismatch_base %>%
  group_by(gu) %>%
  summarise(
    mean_E = mean(E_gt, na.rm = TRUE),
    n_day = n_distinct(date),
    mean_sales = mean(Sales, na.rm = TRUE),
    mean_flowin = mean(FlowIn, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(mean_E)

mismatch_table


############################
# 7. 하위 25% 기준값 계산
############################

q25 <- quantile(
  mismatch_table$mean_E,
  probs = 0.25,
  na.rm = TRUE
)

q25

############################
# 8. Mismatch 더미 생성
############################

mismatch_table <- mismatch_table %>%
  mutate(
    Mismatch = ifelse(mean_E <= q25, 1, 0)
  ) %>%
  arrange(mean_E)

mismatch_table



############################
# 9. 불일치 지역 확인
############################

mismatch_table %>%
  filter(Mismatch == 1) %>%
  arrange(mean_E)

mismatch_table %>%
  count(Mismatch)



############################
# 10. 결과 저장
############################

write_xlsx(
  list(
    "sales_gu_day" = sales_gu_day,
    "flow_gu_day" = flow_gu_day,
    "mismatch_base" = mismatch_base,
    "mismatch_table" = mismatch_table
  ),
  path = "C:/Users/bluem/Desktop/빅데캠/mismatch_check.xlsx"
)









