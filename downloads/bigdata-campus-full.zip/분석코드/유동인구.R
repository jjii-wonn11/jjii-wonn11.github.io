library(dplyr)
library(lubridate)
library(readr)
library(stringr)

############################
# 0. 저장 폴더 설정
############################

out_dir <- "C:/Users/bluem/Desktop/빅데캠/유동인구_전처리_2025"

dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

monthly_dir <- file.path(out_dir, "monthly")
daily_dir   <- file.path(out_dir, "daily")

dir.create(monthly_dir, showWarnings = FALSE, recursive = TRUE)
dir.create(daily_dir, showWarnings = FALSE, recursive = TRUE)


############################
# 1. code_table 자료형 정리
############################

code_table <- code_table %>%
  mutate(
    arv_emd = as.character(arv_emd),
    gu = as.character(gu)
  )


############################
# 2. 유동인구: 도착 행정동 x 일별 합산
############################

flow_emd_day <- flow_raw %>%
  mutate(
    # arv_dt 형식에 따라 아래 둘 중 하나 사용
    # date = as.Date(as.character(arv_dt), format = "%Y%m%d"),
    date = as.Date(arv_dt),
    
    arv_emd = as.character(arv_emd),
    FlowIn = as.numeric(popl_cnt)
  ) %>%
  filter(
    !is.na(date),
    !is.na(arv_emd),
    !is.na(FlowIn)
  ) %>%
  filter(
    year(date) == 2025
  ) %>%
  group_by(arv_emd, date) %>%
  summarise(
    FlowIn = sum(FlowIn, na.rm = TRUE),
    .groups = "drop"
  )


############################
# 3. 행정동 코드 → 행정구 변환 후 행정구 x 일별 합산
############################

flow_gu_day <- flow_emd_day %>%
  left_join(code_table, by = "arv_emd") %>%
  filter(
    !is.na(gu)
  ) %>%
  group_by(gu, date) %>%
  summarise(
    FlowIn = sum(FlowIn, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(gu, date)


############################
# 4. 유동인구 전처리 결과 확인
############################

flow_gu_day %>%
  summarise(
    n_row = n(),
    n_gu = n_distinct(gu),
    n_date = n_distinct(date),
    min_date = min(date, na.rm = TRUE),
    max_date = max(date, na.rm = TRUE),
    missing_flowin = sum(is.na(FlowIn)),
    min_flowin = min(FlowIn, na.rm = TRUE),
    max_flowin = max(FlowIn, na.rm = TRUE)
  )

flow_gu_day %>%
  count(gu, sort = TRUE)

flow_gu_day %>%
  mutate(
    month = month(date)
  ) %>%
  count(month, name = "n_row")


############################
# 5. 전체 행정구 x 일별 유동인구 저장
############################

write_excel_csv(
  flow_gu_day,
  file.path(out_dir, "flow_gu_day_2025_total.csv")
)


############################
# 6. 월별 파일 저장
############################

for (m in 1:12) {
  
  flow_month <- flow_gu_day %>%
    filter(month(date) == m)
  
  file_name <- paste0(
    "2025_",
    sprintf("%02d", m),
    "_flow_gu_day.csv"
  )
  
  write_excel_csv(
    flow_month,
    file.path(monthly_dir, file_name)
  )
}



############################
# 7. 일별 파일 저장
############################

date_list <- sort(unique(flow_gu_day$date))

for (d in date_list) {
  
  d <- as.Date(d)
  
  month_folder <- file.path(
    daily_dir,
    paste0(format(d, "%m"), "월")
  )
  
  dir.create(month_folder, showWarnings = FALSE, recursive = TRUE)
  
  flow_day <- flow_gu_day %>%
    filter(date == d)
  
  file_name <- paste0(
    format(d, "%Y%m%d"),
    "_flow_gu_day.csv"
  )
  
  write_excel_csv(
    flow_day,
    file.path(month_folder, file_name)
  )
}



############################
# 8. 저장 파일 개수 확인
############################

length(list.files(monthly_dir, pattern = "\\.csv$", full.names = TRUE))

length(list.files(daily_dir, pattern = "\\.csv$", full.names = TRUE, recursive = TRUE))





