library(readxl)
library(dplyr)
library(lubridate)
library(tidyr)
library(zoo)
library(writexl)

##################소비자물가지수 불러오기##################

cpi_path <- "C:/Users/bluem/Desktop/빅데캠/소비자물가지수(지출목적별)_20260421225613.xlsx"

cpi_raw <- read_excel(
  cpi_path,
  sheet = "데이터"
)

##################소비자물가지수 월별 데이터 생성##################
# 주의: slice(-1)만 해야 함
# slice(-(1:2))로 하면 2025년 1월까지 빠짐

cpi_monthly <- cpi_raw %>%
  slice(-1) %>%          # 설명 행만 제거
  select(시점, 총지수) %>%
  mutate(
    month_chr = as.character(시점),
    cpi = as.numeric(총지수),
    month_chr2 = gsub("\\.\\s*", "-", month_chr),
    month = as.Date(paste0(month_chr2, "-01"), format = "%Y-%m-%d")
  ) %>%
  filter(
    !is.na(month),
    !is.na(cpi)
  ) %>%
  arrange(month) %>%
  select(
    month,
    cpi
  )

##################월별 CPI를 일별로 확장##################
# 같은 월 안에서는 같은 CPI 값을 반복

cpi_daily_base <- cpi_monthly %>%
  rowwise() %>%
  mutate(
    date = list(seq.Date(
      from = month,
      to = ceiling_date(month, "month") - days(1),
      by = "day"
    ))
  ) %>%
  unnest(date) %>%
  ungroup() %>%
  arrange(date) %>%
  select(
    date,
    month,
    cpi
  )

##################당일 제외 직전 30일 CPI 평균##################

cpi_daily <- cpi_daily_base %>%
  arrange(date) %>%
  mutate(
    cpi_ma30 = rollapplyr(
      lag(cpi, 1),
      width = 30,
      FUN = mean,
      fill = NA,
      partial = FALSE
    )
  )

##################확인##################

cpi_monthly

cpi_daily %>%
  filter(date >= as.Date("2025-01-25"),
         date <= as.Date("2025-02-05"))

cpi_daily %>%
  summarise(
    n_day = n(),
    start_date = min(date),
    end_date = max(date),
    missing_cpi = sum(is.na(cpi)),
    missing_cpi_ma30 = sum(is.na(cpi_ma30))
  )

##################엑셀로 내보내기##################

write_xlsx(
  list(
    "CPI_monthly" = cpi_monthly,
    "CPI_daily_base" = cpi_daily_base,
    "CPI_daily_ma30" = cpi_daily
  ),
  path = "C:/Users/bluem/Desktop/빅데캠/cpi_check.xlsx"
)